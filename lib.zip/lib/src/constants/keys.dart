class Keys {
  static const String emailPassword = 'email-password';
  static const String anonymous = 'anonymous';
  static const String tabBar = 'tabBar';
  static const String jobsTab = 'jobsTab';
  static const String entriesTab = 'entriesTab';
  static const String accountTab = 'accountTab';
  static const String logout = 'logout';
  static const String alertDefault = 'alertDefault';
  static const String alertCancel = 'alertCancel';
}
