// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$authProvidersHash() => r'8a83535c31539dac72f21c3f27b7d7fb77161e5f';

/// See also [authProviders].
@ProviderFor(authProviders)
final authProvidersProvider =
    Provider<List<AuthProvider<AuthListener, AuthCredential>>>.internal(
  authProviders,
  name: r'authProvidersProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$authProvidersHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef AuthProvidersRef
    = ProviderRef<List<AuthProvider<AuthListener, AuthCredential>>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
