import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:starter_architecture_flutter_firebase/src/common_widgets/responsive_center.dart';
import 'package:starter_architecture_flutter_firebase/src/constants/breakpoints.dart';
import 'package:starter_architecture_flutter_firebase/src/features/jobs/domain/job.dart';
import 'package:starter_architecture_flutter_firebase/src/features/jobs/presentation/edit_job_screen/edit_job_screen_controller.dart';
import 'package:starter_architecture_flutter_firebase/src/utils/async_value_ui.dart';

class EditJobScreen extends ConsumerStatefulWidget {
  const EditJobScreen({super.key, this.jobId, this.job});
  final JobID? jobId;
  final Job? job;

  @override
  ConsumerState<EditJobScreen> createState() => _EditJobPageState();
}

class _EditJobPageState extends ConsumerState<EditJobScreen> {
  final _formKey = GlobalKey<FormState>();

  String? _name;
  
  // NEW: Pricing fields
  late JobPricingType _pricingType; 
  int? _ratePerHour;
  double? _fixedPrice;
  String? _clientId;
  
  // Client information fields
  String? _clientName;
  String? _clientEmail;
  String? _clientCompany;
  String? _clientPhone;

  @override
  void initState() {
    super.initState();
    if (widget.job != null) {
      _name = widget.job?.name;
      
      // NEW: Initialize pricing fields
      _pricingType = widget.job?.pricingType ?? JobPricingType.hourly;
      _ratePerHour = widget.job?.ratePerHour;
      _fixedPrice = widget.job?.fixedPrice;
      _clientId = widget.job?.clientId;

      // Initialize client fields
      _clientName = widget.job?.clientName;
      _clientEmail = widget.job?.clientEmail;
      _clientCompany = widget.job?.clientCompany;
      _clientPhone = widget.job?.clientPhone;
    } else {
      // Set default pricing type for new job
      _pricingType = JobPricingType.hourly;
    }
  }

  bool _validateAndSaveForm() {
    final form = _formKey.currentState!;
    if (form.validate()) {
      form.save();
      
      // Custom validation for pricing
      if (_pricingType == JobPricingType.hourly && (_ratePerHour == null || _ratePerHour! <= 0)) {
        // Can be handled by validator above, but redundant check is safe
        return true;
      }
      if (_pricingType == JobPricingType.fixedPrice && (_fixedPrice == null || _fixedPrice! <= 0)) {
        // Can be handled by validator above
        return true;
      }
      
      return true;
    }
    return false;
  }

  Future<void> _submit() async {
    if (_validateAndSaveForm()) {
      final success =
          await ref.read(editJobScreenControllerProvider.notifier).submit(
                jobId: widget.jobId,
                oldJob: widget.job,
                name: _name ?? '',
                
                // NEW: Pass pricing info, ensuring only one value is non-null
                pricingType: _pricingType,
                ratePerHour: _pricingType == JobPricingType.hourly ? _ratePerHour : null,
                fixedPrice: _pricingType == JobPricingType.fixedPrice ? _fixedPrice : null,
                clientId: _clientId,
                
                // Pass client information
                clientName: _clientName ?? '',
                clientEmail: _clientEmail,
                clientCompany: _clientCompany,
                clientPhone: _clientPhone,
              );
      if (success && mounted) {
        context.pop();
      }
    }
  }

  // Toggle archive status
  Future<void> _toggleArchiveStatus() async {
    final job = widget.job;
    if (job == null) return;

    final newStatus = job.status == JobStatus.active 
        ? JobStatus.archived 
        : JobStatus.active;

    final success =
        await ref.read(editJobScreenControllerProvider.notifier).submit(
              jobId: widget.jobId,
              oldJob: job,
              name: job.name,
              
              // NEW: Preserve pricing type and values when archiving
              pricingType: job.pricingType,
              ratePerHour: job.ratePerHour,
              fixedPrice: job.fixedPrice,
              clientId: job.clientId,
              
              status: newStatus,
              
              // Preserve client information
              clientName: job.clientName,
              clientEmail: job.clientEmail,
              clientCompany: job.clientCompany,
              clientPhone: job.clientPhone,
            );
    if (success && mounted) {
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<AsyncValue>(
      editJobScreenControllerProvider,
      (_, state) => state.showAlertDialogOnError(context),
    );
    final state = ref.watch(editJobScreenControllerProvider);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.job == null ? 'New Job' : 'Edit Job'),
        actions: <Widget>[
          TextButton(
            onPressed: state.isLoading ? null : _submit,
            child: const Text(
              'Save',
              style: TextStyle(fontSize: 18, color: Colors.white),
            ),
          ),
        ],
      ),
      body: _buildContents(),
    );
  }

  Widget _buildContents() {
    return SingleChildScrollView(
      child: ResponsiveCenter(
        maxContentWidth: Breakpoint.tablet,
        padding: const EdgeInsets.all(16.0),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: _buildForm(),
          ),
        ),
      ),
    );
  }

  Widget _buildForm() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: _buildFormChildren(),
      ),
    );
  }

  List<Widget> _buildFormChildren() {
    final List<Widget> children = [
      // Job Information Section
      Text(
        'Job Details',
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.primary,
            ),
      ),
      const SizedBox(height: 12),
      TextFormField(
        decoration: const InputDecoration(
          labelText: 'Job name',
          hintText: 'e.g., Website Development',
          prefixIcon: Icon(Icons.work),
        ),
        keyboardAppearance: Brightness.light,
        initialValue: _name,
        validator: (value) =>
            (value ?? '').isNotEmpty ? null : 'Name can\'t be empty',
        onSaved: (value) => _name = value,
      ),
      
      // NEW: Pricing Type Selector
      const SizedBox(height: 24),
      Text(
        'Pricing Type',
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
            ),
      ),
      const SizedBox(height: 8),
      SegmentedButton<JobPricingType>(
        segments: const <ButtonSegment<JobPricingType>>[
          ButtonSegment<JobPricingType>(
            value: JobPricingType.hourly,
            label: Text('Hourly'),
          ),
          ButtonSegment<JobPricingType>(
            value: JobPricingType.fixedPrice,
            label: Text('Fixed Price'),
          ),
          ButtonSegment<JobPricingType>(
            value: JobPricingType.unpaid,
            label: Text('Unpaid'),
          ),
        ],
        selected: <JobPricingType>{_pricingType},
        onSelectionChanged: (Set<JobPricingType> newSelection) {
          setState(() {
            _pricingType = newSelection.first;
            // Clears unused rate/price fields to avoid saving stale data
            if (_pricingType != JobPricingType.hourly) _ratePerHour = null;
            if (_pricingType != JobPricingType.fixedPrice) _fixedPrice = null;
          });
        },
      ),
      const SizedBox(height: 16),
      
      // NEW: Conditional Pricing Input Field
      if (_pricingType == JobPricingType.hourly)
        TextFormField(
          decoration: const InputDecoration(
            labelText: 'Rate per hour',
            hintText: 'e.g., 50',
            prefixIcon: Icon(Icons.attach_money),
          ),
          keyboardAppearance: Brightness.light,
          initialValue: _ratePerHour != null ? '$_ratePerHour' : null,
          keyboardType: const TextInputType.numberWithOptions(
            signed: false,
            decimal: false,
          ),
          validator: (value) {
            if (_pricingType == JobPricingType.hourly && (value == null || value.isEmpty)) {
              return 'Hourly rate is required';
            }
            return null;
          },
          onSaved: (value) => _ratePerHour = int.tryParse(value ?? '') ?? 0,
        )
      else if (_pricingType == JobPricingType.fixedPrice)
        TextFormField(
          decoration: const InputDecoration(
            labelText: 'Fixed Project Price',
            hintText: 'e.g., 2500.00',
            prefixIcon: Icon(Icons.sell),
          ),
          keyboardAppearance: Brightness.light,
          initialValue: _fixedPrice != null ? _fixedPrice!.toStringAsFixed(2) : null,
          keyboardType: const TextInputType.numberWithOptions(
            signed: false,
            decimal: true,
          ),
          validator: (value) {
            if (_pricingType == JobPricingType.fixedPrice && (value == null || value.isEmpty)) {
              return 'Fixed price is required';
            }
            if (double.tryParse(value ?? '') == null) {
              return 'Please enter a valid number';
            }
            return null;
          },
          onSaved: (value) => _fixedPrice = double.tryParse(value ?? '') ?? 0.0,
        ),
      
      // Existing client information section...
      const SizedBox(height: 32),
      const Divider(),
      const SizedBox(height: 16),
      Text(
        'Client Information (for invoicing)',
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.primary,
            ),
      ),
      const SizedBox(height: 12),
      TextFormField(
        decoration: const InputDecoration(
          labelText: 'Client name',
          hintText: 'e.g., John Smith',
          prefixIcon: Icon(Icons.person),
        ),
        keyboardAppearance: Brightness.light,
        initialValue: _clientName,
        validator: (value) =>
            (value ?? '').isNotEmpty ? null : 'Client name is required for invoicing',
        onSaved: (value) => _clientName = value,
      ),
      const SizedBox(height: 16),
      TextFormField(
        decoration: const InputDecoration(
          labelText: 'Client email',
          hintText: 'e.g., john@company.com',
          prefixIcon: Icon(Icons.email),
        ),
        keyboardAppearance: Brightness.light,
        keyboardType: TextInputType.emailAddress,
        initialValue: _clientEmail,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return null; // Optional field
          }
          if (!value.contains('@')) {
            return 'Please enter a valid email';
          }
          return null;
        },
        onSaved: (value) => _clientEmail = value?.isNotEmpty == true ? value : null,
      ),
      const SizedBox(height: 16),
      TextFormField(
        decoration: const InputDecoration(
          labelText: 'Client company (optional)',
          hintText: 'e.g., Acme Corporation',
          prefixIcon: Icon(Icons.business),
        ),
        keyboardAppearance: Brightness.light,
        initialValue: _clientCompany,
        onSaved: (value) => _clientCompany = value?.isNotEmpty == true ? value : null,
      ),
      const SizedBox(height: 16),
      TextFormField(
        decoration: const InputDecoration(
          labelText: 'Client phone (optional)',
          hintText: 'e.g., +1 234 567 8900',
          prefixIcon: Icon(Icons.phone),
        ),
        keyboardAppearance: Brightness.light,
        keyboardType: TextInputType.phone,
        initialValue: _clientPhone,
        onSaved: (value) => _clientPhone = value?.isNotEmpty == true ? value : null,
      ),
    ];
    
    // Show archive button only when editing existing job
    if (widget.job != null) {
      final isArchived = widget.job!.status == JobStatus.archived;
      children.addAll([
        const SizedBox(height: 32),
        const Divider(),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          onPressed: _toggleArchiveStatus,
          icon: Icon(isArchived ? Icons.unarchive : Icons.archive),
          label: Text(isArchived ? 'Unarchive Job' : 'Archive Job'),
          style: OutlinedButton.styleFrom(
            foregroundColor: isArchived ? Colors.green : Colors.orange,
            side: BorderSide(
              color: isArchived ? Colors.green : Colors.orange,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          isArchived
              ? 'This job is archived. Unarchive it to make it active again.'
              : 'Archive this job to hide it from your active jobs list.',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey[600],
              ),
          textAlign: TextAlign.center,
        ),
      ]);
    }
    
    return children;
  }
}