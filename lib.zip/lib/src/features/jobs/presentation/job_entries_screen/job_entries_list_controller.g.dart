// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'job_entries_list_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$jobsEntriesListControllerHash() =>
    r'f9a08b66a0c962d210a09aebb711d38acb354b1e';

/// See also [JobsEntriesListController].
@ProviderFor(JobsEntriesListController)
final jobsEntriesListControllerProvider =
    AutoDisposeAsyncNotifierProvider<JobsEntriesListController, void>.internal(
  JobsEntriesListController.new,
  name: r'jobsEntriesListControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$jobsEntriesListControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$JobsEntriesListController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
